import React from 'react';
import { View, Text, StyleSheet, Image,} from 'react-native';
import Logo from '../assets/logo.jpg'; 

export function SobreScreen() {

  return(
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <Text style={styles.titulo1}>AE TECH</Text>
        <Image source={Logo} style={styles.imagem}/>
      </View>
      <View style={styles.infoContainer}>
        <Text style={styles.text}>A empresa AE TECH, por meio da integração das disciplinas de DevOps, Mobile, Python e DataBase, tem como objetivo conscientizar a população sobre a importância de não poluir os oceanos. A iniciativa visa educar as pessoas sobre a correta forma de descartar lixo, bem como alertar sobre a quantidade de resíduos gerados diariamente. {'\n'}Em resumo, a AE TECH, desempenha um papel fundamental na conscientização da população sobre a importância de não poluir os oceanos. Ao educar as pessoas sobre o descarte correto de lixo e alertar sobre a quantidade de resíduos gerados diariamente, a empresa contribui para a preservação dos oceanos e do meio ambiente como um todo.</Text>
      </View>
    </View>
  );
  

}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#001f3f',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  titulo1: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    marginTop: 50,
    marginBottom: 50,
  },
  infoContainer: {
    flex: 1,
    alignItems: 'center',
    marginTop: 20,
  },
  text: {
    color: 'white',
    textAlign: 'center',
    margin: 18
  },
  imagem: {
    width: 180,
    height: 180,
    borderRadius: 50,
    marginBottom: 0,
  }
});
