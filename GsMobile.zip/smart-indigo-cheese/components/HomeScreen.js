import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ImageBackground } from 'react-native';
import Fundo from '../assets/oceano.jpg';

export function HomeScreen() {
  const [grams, setGrams] = useState('');
  const [type, setType] = useState('');

  const handleClick = () => {
    console.log("Dados enviados!");
    handleSubmission();
  };

  const handleSubmission = () => {
    console.log(`Gramas: ${grams}, Tipo: ${type}`);
  };

  return (
    <View style={styles.container}>
      <ImageBackground source={Fundo} style={styles.background}>
        <Text style={styles.titulo1}>AE TECH</Text>
      </ImageBackground>
      <View style={styles.formContainer}>
        <Text style={styles.titulo}>Registrar Lixo Produzido</Text>
        <TextInput
          style={styles.input}
          placeholder="Quantos gramas de lixo foi produzido?"
          keyboardType="numeric"
          value={grams}
          onChangeText={setGrams}
        />
        <TextInput
          style={styles.input}
          placeholder="Qual o tipo do lixo?"
          value={type}
          onChangeText={setType}
        />
        <Button
          title="Registrar"
          onPress={handleClick}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#001f3f',
  },
  background: {
    width: '100%',
    height: '65%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  titulo1: {
    fontSize: 34,
    color: 'white',
    textAlign: 'center',
    marginBottom: 60 
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    marginBottom: 200
  },
  titulo: {
    fontSize: 24,
    marginBottom: 20,
    color: 'white',
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    paddingHorizontal: 10,
    borderRadius: 20,
    backgroundColor: 'white',
  },
});
