import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import Perfil from '../assets/eu.jpg'; 

export function ProfileScreen() {
  const handleLogout = () => {
    // Lógica para fazer logout
    console.log("Logout realizado!");
  };

  return (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <Text style={styles.titulo1}>AE TECH</Text>
        <Image source={Perfil} style={styles.perfil} />
      </View>
      <View style={styles.infoContainer}>
        <Text style={styles.title}>Perfil de Erick</Text>
        <Text style={styles.text}>Nome: Erick Soares</Text>
        <Text style={styles.text}>Email: usuario@exemplo.com</Text>
      </View>
      <TouchableOpacity onPress={handleLogout} style={styles.button}>
        <Text style={styles.buttonText}>Sair</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#001f3f',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  perfil: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 0,
  },
  titulo1: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    marginTop: 50,
    marginBottom: 50,
  },
  infoContainer: {
    flex: 1,
    alignItems: 'center',
    marginTop: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    color: 'white',
  },
  text: {
    color: 'white',
  },
  button: {
    backgroundColor: '#850404', // Cor de fundo do botão
    padding: 13,
    borderRadius: 15,
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});
